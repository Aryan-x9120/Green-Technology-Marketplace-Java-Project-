package main.java.com.greentech.dao;
import java.util.List;

import main.java.com.greentech.model.Product;

public interface ProductDAO {
    boolean addProduct(Product p);
    List<Product> getAllProducts();
    boolean approveProduct(int productId);
}