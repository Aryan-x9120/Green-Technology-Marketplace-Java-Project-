package main.java.com.greentech.util;

public class EmailTask implements Runnable {
    private String email;
    public EmailTask(String email) { this.email = email; }

    @Override
    public void run() {
        System.out.println(">> [Background Thread] Sending confirmation email to " + email);
        try { Thread.sleep(2000); } catch (InterruptedException e) {} 
        System.out.println(">> [Background Thread] Email sent!");
    }
}