package main.java.com.greentech.controller;

import com.greentech.model.User;
import com.greentech.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/AuthServlet")
public class AuthServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String pass = request.getParameter("password");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE email=? AND password=?")) {
            ps.setString(1, email);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                User user = new User(rs.getInt("id"), rs.getString("name"), rs.getString("email"), rs.getString("password"), rs.getString("role"));
                HttpSession session = request.getSession();
                session.setAttribute("user", user);

                if ("ADMIN".equals(user.getRole())) response.sendRedirect("dashboard_admin.jsp");
                else if ("VENDOR".equals(user.getRole())) response.sendRedirect("dashboard_vendor.jsp");
                else response.sendRedirect("dashboard_customer.jsp");
            } else {
                response.sendRedirect("login.jsp?error=InvalidCredentials");
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}