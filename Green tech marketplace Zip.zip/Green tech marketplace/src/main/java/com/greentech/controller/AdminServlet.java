package main.java.com.greentech.controller;

import com.greentech.dao.UserDAO;
import com.greentech.model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
    
    private UserDAO userDAO = new UserDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("deleteUser".equals(action)) {
            int userId = Integer.parseInt(request.getParameter("id"));
            userDAO.deleteUser(userId);
            // Redirect back to dashboard to see changes
            response.sendRedirect("dashboard_admin.jsp?msg=UserDeleted");
        } 
        else if ("createUser".equals(action)) {
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String pass = request.getParameter("password");
            String role = request.getParameter("role");
            
            User newUser = new User(0, name, email, pass, role);
            userDAO.addUser(newUser);
            response.sendRedirect("dashboard_admin.jsp?msg=UserCreated");
        }
    }
}