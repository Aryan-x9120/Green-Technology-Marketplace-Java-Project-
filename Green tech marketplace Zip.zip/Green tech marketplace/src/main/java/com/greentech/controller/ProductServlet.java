package main.java.com.greentech.controller;

import com.greentech.dao.ProductDAO;
import com.greentech.dao.ProductDAOImpl;
import com.greentech.model.Product;
import com.greentech.util.EmailTask;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAOImpl();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            String name = request.getParameter("name");
            String desc = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));
            productDAO.addProduct(new Product(0, name, desc, price, "PENDING"));
            response.sendRedirect("dashboard_vendor.jsp?msg=Added");
        } 
        else if ("approve".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            productDAO.approveProduct(id);
            response.sendRedirect("dashboard_admin.jsp");
        }
        else if ("buy".equals(action)) {
            new Thread(new EmailTask("customer@example.com")).start(); // Multithreading
            response.sendRedirect("dashboard_customer.jsp?msg=OrderSuccess");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Product> products = productDAO.getAllProducts();
        request.setAttribute("productList", products);
        request.getRequestDispatcher("browse_products.jsp").forward(request, response);
    }
}