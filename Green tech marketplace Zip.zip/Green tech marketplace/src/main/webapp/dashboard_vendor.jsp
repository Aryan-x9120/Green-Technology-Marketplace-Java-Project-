<!DOCTYPE html>
<html>
<body>
    <h1>Vendor Dashboard</h1>
    <h3>Add New Product</h3>
    <form action="ProductServlet" method="post">
        <input type="hidden" name="action" value="add">
        Name: <input type="text" name="name"><br>
        Desc: <input type="text" name="description"><br>
        Price: <input type="number" name="price"><br>
        <button type="submit">List Product</button>
    </form>
</body>
</html>